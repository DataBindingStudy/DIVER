package com.test.helloworld;

import org.springframework.beans.BeanWrapperImpl;
import org.springframework.beans.Spring_Instrumentation;
import org.springframework.boot.autoconfigure.web.format.DateTimeFormatters;
import org.springframework.boot.autoconfigure.web.format.WebConversionService;

import org.apache.http.HttpEntity;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.util.*;


class Queue_member{
    BindingNode node;
    String path;
    int depth;
    Object obj;
}
public class MyMapUtil {
    private static DateTimeFormatters dateTimeFormatters = new DateTimeFormatters();
    private static WebConversionService conversionService = new WebConversionService(dateTimeFormatters);
    public static ArrayList<String> result_list = new ArrayList<>();
    public static ArrayList<String> bindable_list = new ArrayList<>();
    public static long allpath_count=0;
    public static String Base_URL="http://localhost:8080";
    public static int count=0;
    public static boolean Test_Bindable=false;
    public static boolean Test_Recusive=false;
    public static LinkedList<Queue_member> queue = new LinkedList<>();
    public static ListGraph listGraph=new ListGraph();

    public static void clear(){
        listGraph.clear();
        Test_Bindable=false;
        Test_Recusive=false;
        result_list.clear();
        bindable_list.clear();
        allpath_count=0;
        queue.clear();
    }

    public static void start_test(){
        try {
            String res=sendGet(Base_URL+"/ChangeStartFlag");
            if (res.equals("false"))
                sendGet(Base_URL+"/ChangeStartFlag");
        } catch (Exception e) {
        }
    }

    public static String sendGet(String url) {
        try {
            CloseableHttpClient client = HttpClients.createDefault();
            HttpGet request = new HttpGet(url);
            CloseableHttpResponse response = client.execute(request);
            String result = EntityUtils.toString(response.getEntity());
            return result;

        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }
    public static String sendPost(String url,String key,String value){

        HttpPost post = new HttpPost(url);
        try {
            List<BasicNameValuePair> list = new ArrayList<BasicNameValuePair>();
            list.add(new BasicNameValuePair(key,value));
            post.setEntity(new UrlEncodedFormEntity(list, "UTF-8"));
            CloseableHttpClient client = HttpClients.createDefault();
            CloseableHttpResponse response = client.execute(post);
            HttpEntity entity = response.getEntity();
            if (response.getStatusLine().getStatusCode() == 200) {
                return EntityUtils.toString(entity, "UTF-8");
            }
            else{
                return sendGet(url);
            }

        } catch (Exception e1) {
            e1.printStackTrace();
        }
        return "";
    }

    public static void test_chain(String target,String value){
        if (!Spring_Instrumentation.StartFlag){
            Test_Bindable = false;
            Test_Recusive = true;
            return;
        }
        String res=sendPost(Base_URL+"/greeting",target,value);
        int index = res.indexOf("_");
        if (index > 0) {
            Test_Bindable = Boolean.parseBoolean(res.substring(index + 1));
            Test_Recusive = Boolean.parseBoolean(res.substring(0, index));
        } else {
            Test_Bindable = false;
            Test_Recusive = false;
        }

    }
    public static Object getValueByFiled(Object obj, Field field) {
        if (obj == null || field == null) {
            return null;
        }
        try {
            field.setAccessible(true);
            return field.get(obj);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    public static void TryAddQueueMemeber(Queue_member now, Object obj, String name){
        BindingNode next;
        String path;
        if (now.path.isEmpty()){
            path=name;
        }
        else{
            path=now.path+"."+name;
        }
        String value=obj.toString();
        if (value.contains("E1rr0r_") || value.length()>300){
            value="1";
        }
        if (listGraph.isInGraph(obj)){
            next = listGraph.getNodeByObject(obj);
            test_chain(path,value);
            if (Test_Recusive){
                listGraph.addEdge(now.node, name, next);
                if (Test_Bindable){
                    if (!next.isBindable){
                        bindable_list.add(path +" "+ next.type+" "+ next.Mstring);
                    }
                    next.isBindable=true;
                }
            }

        }
        else {
            test_chain(path,value);
            if (Test_Recusive) {
                next = listGraph.addNode(obj);
                listGraph.addEdge(now.node, name, next);
                if (Test_Bindable){
                    bindable_list.add(path +" "+ next.type+" "+ next.Mstring);
                    next.isBindable=true;
                }
                //add to queue
                Queue_member qm = new Queue_member();
                qm.node = next;
                qm.path = path;
                qm.obj = obj;
                qm.depth= now.depth-1;
                queue.add(qm);
            }
        }
    }
    public static void findandFillinGraph_BFS(Object start,String start_path,int depth) {

        BeanWrapperImpl impl;

        if (start==null)
        {
            System.out.println("First Object cannot be null!");
            return;
        }
        //创建队列的第一个节点
        Queue_member qm=new Queue_member();
        qm.node=listGraph.addNode(start);
        listGraph.firstNode=qm.node;
        qm.path=start_path;
        qm.obj=start;
        qm.depth=depth;
        queue.add(qm);
        //BFS
        while (queue.size()!=0) {
            try{
                qm = queue.poll();
                result_list.add(qm.path);
                if (qm.depth<=0) continue;
                if (listGraph.isBaseType(qm.obj))
                {
                    if (listGraph.BaseTypeVisited.contains(qm.obj.getClass()) || qm.obj.getClass().equals(java.lang.String.class) && qm.obj.toString().contains("E1rr0r_"))
                        continue;
                    else
                        listGraph.BaseTypeVisited.add(qm.obj.getClass());
                }
                impl = new BeanWrapperImpl(qm.obj);
                for (PropertyDescriptor pd : impl.getPropertyDescriptors() ) {
                    try{
                        if (pd.getName().equals("accessible")) continue;
                        Object next_obj=null;
                        try {
                            next_obj = impl.getPropertyValue(pd.getName());
                        }
                        catch (Exception ignored){
                        }
                        if (next_obj!=null){
                            if (pd.getPropertyType().isArray()) {
                                Object[] array = (Object[]) next_obj;
                                for (int i = 0; i < array.length; i++) {
                                    TryAddQueueMemeber(qm, array[i], pd.getName() + "[" + i + "]");
                                }
                            }
                            else if (List.class.isAssignableFrom(pd.getPropertyType())) {
                                List<Object> list = (List<Object>) next_obj;
                                for (int i = 0; i < list.size(); i++) {
                                    TryAddQueueMemeber(qm,list.get(i),pd.getName() + "[" + i + "]");
                                }
                            }
                            else if (Map.class.isAssignableFrom(pd.getPropertyType())) {
                                /*Map map = (Map) next_obj;
                                if (!map.isEmpty()) {
                                    Iterator iterator = map.keySet().iterator();
                                    while (iterator.hasNext()) {
                                        Object key = iterator.next();
                                        TryAddQueueMemeber(qm,map.get(key),pd.getName() + "[" + key + "]");
                                    }

                                }*/
                            }
                            else {
                                TryAddQueueMemeber(qm,next_obj,pd.getName());
                            }

                        }
                        else{
                            TryAddQueueMemeber(qm,"E1rr0r_"+qm.path+pd.getName()+"_M1typed_"+pd.getPropertyType().getName(),pd.getName());
                        }
                    }
                    catch(Exception ignored){

                    }
                }
            }
            catch (Exception ignored){
            }
        }
    }
    public static void find_allpath_inGraph(BindingNode now,int depth) {
        /*Queue_member qm,qm2;
        qm=new Queue_member();
        qm.node=listGraph.firstNode;
        qm.depth=depth;
        queue.add(qm);
        allpath_count=0;
        while (queue.size()!=0) {
            try{
                qm = queue.poll();
                allpath_count++;
                if (qm.depth<=0) continue;
                for (BindingNode node : qm.node.edgeList.values()) {
                    qm2=new Queue_member();
                    qm2.node=node;
                    qm2.depth=qm.depth-1;
                    queue.add(qm2);
                }
            }
            catch (Exception ignored){
            }
        }*/
        allpath_count++;
        BindingNode next;
        if (depth<=0)
            return;
        for (Map.Entry<String,BindingNode> entry: now.edgeList.entrySet()) {
            next=entry.getValue();
            if (!next.isVisited){
                next.isVisited=true;
                find_allpath_inGraph(next,depth-1);
                next.isVisited=false;
            }

        }
    }
    public static HashSet<String> findWritablePds(Object root, String path, int depth, HashSet<Object> visited) {

        if (visited == null) {
            visited = new HashSet<>();
            visited.add(Integer.class);
            visited.add(Long.class);
            visited.add(Double.class);
            visited.add(String.class);
        }

        HashSet<String> res = new HashSet<>();
        if (depth <= 0) return res;
        if (visited.contains(root)) return res;
        else visited.add(root);

        try {
            BeanWrapperImpl impl = new BeanWrapperImpl(root);

            for (PropertyDescriptor pd : impl.getPropertyDescriptors()) {
                count++;
                System.out.println(path+"."+pd.getName());
                if (!impl.isReadableProperty(pd.getName())) continue;
                if (pd.getName().equals("accessible")) continue;
                if (impl.isWritableProperty(pd.getName())) {
                    String ss="";
                    try{
                        ss= impl.getPropertyValue(pd.getName()).toString();
                        if (ss.length() >300){
                            ss="1";
                        }
                    }
                    catch (Exception ignored)
                    {
                    }
                    res.add(path + "." + pd.getName()+" "+pd.getPropertyType()+" "+ss);
                }
                Object value = impl.getPropertyValue(pd.getName());

                if (value != null && value != Optional.empty()) {
                    res.addAll(findWritablePds(value, path + "." + pd.getName(), depth - 1, visited));

                    if (value.getClass().isArray()) {
                        try {
                            Object[] casted = (Object[]) value;
                            for (int i = 0; i < casted.length; i++) {
                                res.addAll(findWritablePds(casted[i], path + "." + pd.getName() + "[" + i + "]", depth - 1, visited));
                            }
                        } catch (ClassCastException cce) {
                            System.err.println("Exception casting class " + value.getClass().getCanonicalName() + ": " + cce.getMessage());
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return res;
    }
}