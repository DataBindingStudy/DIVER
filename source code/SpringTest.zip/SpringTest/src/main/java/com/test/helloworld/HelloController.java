package com.test.helloworld;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.Date;
import java.util.HashSet;

import org.springframework.beans.Spring_Instrumentation;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

@Controller
public class HelloController {
    @Autowired
    private HttpServletRequest request;

    @GetMapping("/FindwithBFS")
    public String greetingBFS(@RequestParam(name= "depth",defaultValue="10") String dp, Model model) {
        MyMapUtil.clear();
        String url=request.getRequestURL().toString();
        MyMapUtil.Base_URL=url.substring(0,url.indexOf("/FindwithBFS"));
        Greeting greeting = new Greeting();

        int depth=10;
        if (dp!=null){
            depth=Integer.parseInt(dp);
        }
        Date start = new Date();
        MyMapUtil.start_test();
        MyMapUtil.findandFillinGraph_BFS(greeting, "",depth);
        Date stop = new Date();
        String res= "NP=ANP: "+MyMapUtil.result_list.size()+" --- EdgeNum: "+MyMapUtil.listGraph.edgenum+" --- BNP: "+MyMapUtil.bindable_list.size()+" --- Time: "+String.valueOf(stop.getTime() -start.getTime())+" ms";
        model.addAttribute("myResult1",res);
        model.addAttribute("myResult2",MyMapUtil.bindable_list);
        return "hello";
    }
    @GetMapping("/GetAllPath")
    public String getallpath(@RequestParam(name= "depth",defaultValue="5") String dp, Model model) {
        MyMapUtil.clear();
        String url=request.getRequestURL().toString();
        MyMapUtil.Base_URL=url.substring(0,url.indexOf("/GetAllPath"));
        Greeting greeting = new Greeting();

        int depth=5;
        if (dp!=null){
            depth=Integer.parseInt(dp);
        }
        Date start = new Date();
        MyMapUtil.start_test();
        MyMapUtil.findandFillinGraph_BFS(greeting, "",depth);
        MyMapUtil.listGraph.firstNode.isVisited=true;
        MyMapUtil.find_allpath_inGraph(MyMapUtil.listGraph.firstNode,depth);
        Date stop = new Date();
        String res= "NP=ANP: "+MyMapUtil.result_list.size()+" --- EdgeNum: "+MyMapUtil.listGraph.edgenum+" --- allpath_count: "+MyMapUtil.allpath_count+" --- BNP: "+MyMapUtil.bindable_list.size()+" --- Time: "+String.valueOf(stop.getTime() -start.getTime())+" ms";
        model.addAttribute("myResult1",res);
        return "hello";
    }


    @GetMapping("/FindwithSnyk")
    public String greetingForm(@RequestParam(name= "depth",defaultValue="10") String dp,Model model) {

        int depth=10;
        if (dp!=null){
            depth=Integer.parseInt(dp);
        }

        Greeting greeting = new Greeting();
        HashSet<String> myResult = MyMapUtil.findWritablePds(greeting, "", depth, null);
        model.addAttribute("myResult1",MyMapUtil.count+"  "+myResult.size());
        model.addAttribute("myResult2", myResult);
        return "hello";
    }

    @GetMapping("/ChangeStartFlag")
    @ResponseBody
    public boolean ChangeStartFlag() {
        Spring_Instrumentation.StartFlag= !Spring_Instrumentation.StartFlag;
        Spring_Instrumentation.restore_defaults();
        return Spring_Instrumentation.StartFlag;
    }

    @GetMapping("/ChangeDebugFlag")
    @ResponseBody
    public boolean ChangeDebugFlag( ) {
        Spring_Instrumentation.DebugFlag= !Spring_Instrumentation.DebugFlag;
        Spring_Instrumentation.restore_defaults();
        return Spring_Instrumentation.DebugFlag;
    }

    @GetMapping("/StartDebug")
    @ResponseBody
    public String StartDebug() {
        Spring_Instrumentation.DebugFlag= true;
        Spring_Instrumentation.StartFlag=false;
        Spring_Instrumentation.restore_defaults();
        return "go";
    }

    @GetMapping("/GetThread")
    @ResponseBody
    public int get_thread() {
        return Thread.activeCount();
    }

    @GetMapping("/greeting")
    @ResponseBody
    public String greetingSubmit(Greeting greeting, Model model) {
        String result="";
        if(Spring_Instrumentation.DebugFlag){
            result="Write_method:"+Spring_Instrumentation.write_method+"------OldValue:"+Spring_Instrumentation.original_value+"------NewValue:"+Spring_Instrumentation.new_value;
            Spring_Instrumentation.restore_defaults();
        }
        else if (Spring_Instrumentation.StartFlag){
            result=Spring_Instrumentation.recursionflag+"_"+Spring_Instrumentation.bindingflag;
            Spring_Instrumentation.restore_defaults();
        }
        return result;
    }

    @PostMapping ("/greeting")
    @ResponseBody
    public String greetingSubmit2(Greeting greeting, Model model) {
        String result="";
        if(Spring_Instrumentation.DebugFlag){
            result="Write_method:"+Spring_Instrumentation.write_method+"------OldValue:"+Spring_Instrumentation.original_value+"------NewValue:"+Spring_Instrumentation.new_value;
            Spring_Instrumentation.restore_defaults();
        }
        else if (Spring_Instrumentation.StartFlag){
            result=Spring_Instrumentation.recursionflag+"_"+Spring_Instrumentation.bindingflag;
            Spring_Instrumentation.restore_defaults();
        }
        return result;
    }

}
