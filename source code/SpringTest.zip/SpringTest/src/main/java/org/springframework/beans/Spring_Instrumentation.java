package org.springframework.beans;

public class Spring_Instrumentation {
    public static boolean StartFlag;
    public static boolean DebugFlag=false;
    public static String original_value ="GetErr10r";
    public static String new_value ="GetErr10r";
    public static String write_method ="GetErr10r";
    public static boolean bindingflag;
    public static boolean recursionflag;

    private Spring_Instrumentation(){}
    public static void restore_defaults(){
        //request = "";
        bindingflag=false;
        recursionflag=false;
        original_value="GetErr10r";
        new_value ="GetErr10r";
        write_method ="GetErr10r";
    }

    public static void do_recursion()
    {
        if (!StartFlag) return;
        recursionflag=true;
    }

    public static void do_binding()
    {
        if (!StartFlag) return;
        bindingflag=true;
    }

}
