package garilsmain

import grails.testing.web.controllers.ControllerUnitTest
import spock.lang.Specification

class GetAllPathControllerSpec extends Specification implements ControllerUnitTest<GetAllPathController> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
