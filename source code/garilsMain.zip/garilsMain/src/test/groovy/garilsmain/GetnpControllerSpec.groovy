package garilsmain

import grails.testing.web.controllers.ControllerUnitTest
import spock.lang.Specification

class GetnpControllerSpec extends Specification implements ControllerUnitTest<GetnpController> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
