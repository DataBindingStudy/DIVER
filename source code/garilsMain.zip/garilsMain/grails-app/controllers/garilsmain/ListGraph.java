package garilsmain;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class ListGraph {
    Map<Object, BindingNode> Non_Primitive_Node= new HashMap<Object, BindingNode>();
    ArrayList<BindingNode> Primitive_Binding_Node = new ArrayList<BindingNode>();
    BindingNode firstNode=null;
    HashSet<Class> BaseTypeVisited = new HashSet<Class>();
    /**
     * 判断object是否为基本类型
     * @param object
     * @return
     */
    public static boolean isBaseType(Object object) {
        Class className = object.getClass();
        if (className.equals(java.lang.String.class) ||
                className.equals(java.lang.Integer.class) ||
                className.equals(java.lang.Byte.class) ||
                className.equals(java.lang.Long.class) ||
                className.equals(java.lang.Double.class) ||
                className.equals(java.lang.Float.class) ||
                className.equals(java.lang.Character.class) ||
                className.equals(java.lang.Short.class) ||
                className.equals(java.lang.Boolean.class)) {
            return true;
        }
        return false;
    }
    public boolean not_in_Primitive_Node(Object obj){
        //认为基本类型对象每一个都是独立的
        return true;
    }
    public boolean isInGraph(Object obj){
        if (isBaseType(obj) && not_in_Primitive_Node(obj))
            return false;
        else if (Non_Primitive_Node.containsKey(obj))
            return true;
        else
            return false;
    }
    public BindingNode addNode(Object obj){
        //System.out.println("addnote "+obj.toString());
        if (this.isInGraph(obj)){
            return null;
        }

        BindingNode newBindingNode =new BindingNode();
        int index=0;
        newBindingNode.Mstring=obj.toString();
        if (newBindingNode.Mstring.contains("E1rr0r_") ){
            index=newBindingNode.Mstring.indexOf("_M1typed_");
            newBindingNode.type=newBindingNode.Mstring.substring(index+9);
            newBindingNode.Mstring="E1rr0r_ReadError";
        }
        else if (newBindingNode.Mstring.length()>300) {
            newBindingNode.Mstring="E1rr0r_too_long";
        } else if (newBindingNode.Mstring.contains("\r")) {
            index=newBindingNode.Mstring.indexOf("\r");
            newBindingNode.Mstring=newBindingNode.Mstring.substring(0,index);
        } else  if (newBindingNode.Mstring.contains("\n")) {
            index=newBindingNode.Mstring.indexOf("\n");
            newBindingNode.Mstring=newBindingNode.Mstring.substring(0,index);
        }
        if (!newBindingNode.Mstring.equals("E1rr0r_ReadError")) {
            newBindingNode.type = obj.getClass().getTypeName();
            if (obj instanceof Enum<?>) {
                newBindingNode.type = "Enum_type";
                Class<?> enumClass = ((Enum<?>) obj).getDeclaringClass();
                Object[] values = enumClass.getEnumConstants();
                for (Object ss : values) {
                    newBindingNode.Mstring = newBindingNode.Mstring + " " + ss.toString();
                }
            }
        }
        if (isBaseType(obj)){  //基本类型
            Primitive_Binding_Node.add(newBindingNode);
            return newBindingNode;
        }
        else {  //引用类型
            Non_Primitive_Node.put(obj, newBindingNode);
            return newBindingNode;
        }
    }
    public void addEdge(BindingNode a, String name,BindingNode b){
        if (a==null || b==null)
            return;
        a.edgeList.put(name,b);
    }
    public BindingNode getNodeByObject(Object obj){
        if (!this.isInGraph(obj)){
            return null;
        }
        return Non_Primitive_Node.get(obj);
    }
    public BindingNode getNodeByPath(String path){

        return null;
    }
    public int getNodesize(){
        return Non_Primitive_Node.size()+ Primitive_Binding_Node.size();
    }

    public void clear(){
        BaseTypeVisited.clear();
        Primitive_Binding_Node.clear();
        Non_Primitive_Node.clear();
        firstNode=null;
        //edgenum=0;
    }


}