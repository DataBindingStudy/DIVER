package garilsmain

import org.codehaus.groovy.util.ComplexKeyHashMap
import org.codehaus.groovy.util.SingleKeyHashMap
import grails.databinding.Grails_Instrumentation
import groovy.time.TimeCategory
import groovy.time.TimeDuration


import org.apache.http.HttpEntity;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils

import java.lang.reflect.Modifier;

class Queue_member{
    BindingNode node;
    int depth;
    String path;
    Object obj;
}

public class NewGetPropertyChain {
    public static int BNP_count=0;
    public static long allpath_count=0;
    public static boolean Test_Bindable;
    public static boolean Test_Recusive;
    public static String base_url="http://localhost:8080";

    public static ListGraph listGraph=new ListGraph();
    public static File file=new File("myLog.txt");
    public static File file2=new File("bindable.txt");
    public static WritetoFile(String s){
        file.append(s+"\n");
    }
    public static WritetoFile2(String s){
        BNP_count++;
        file2.append(s+"\n");
    }

    public static SingleKeyHashMap getProperties(Object obj){
        MetaClassImpl metaClassImpl = new MetaClassImpl(obj.getClass());
        metaClassImpl.initialize();
        SingleKeyHashMap propertyMap = metaClassImpl.classPropertyIndex.getNotNull(metaClassImpl.theCachedClass);
        return propertyMap
    }

    public static String sendGet(String url) {
        try {
            CloseableHttpClient client = HttpClients.createDefault();
            HttpGet request = new HttpGet(url);
            CloseableHttpResponse response = client.execute(request);
            String result = EntityUtils.toString(response.getEntity());
            return result;

        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }
    public static String sendPost(String url,String key,String value){

        HttpPost post = new HttpPost(url);
        try {
            List<BasicNameValuePair> list = new ArrayList<BasicNameValuePair>();
            list.add(new BasicNameValuePair(key,value));
            post.setEntity(new UrlEncodedFormEntity(list, "UTF-8"));
            CloseableHttpClient client = HttpClients.createDefault();
            CloseableHttpResponse response = client.execute(post);
            HttpEntity entity = response.getEntity();
            if (response.getStatusLine().getStatusCode() == 200) {
                return EntityUtils.toString(entity, "UTF-8");
            }
            else{
                return sendGet(url);
            }

        } catch (Exception e1) {
            e1.printStackTrace();
        }
        return "";
    }

    public static void test_chain(String target,String value){
        if (!Grails_Instrumentation.StartFlag){
            Test_Bindable = false;
            Test_Recusive = true;
            return
        }
        String res=sendPost(base_url+"/book",target,value);
        int index = res.indexOf("_");
        if (index > 0) {
            Test_Bindable = Boolean.parseBoolean(res.substring(index + 1));
            Test_Recusive = Boolean.parseBoolean(res.substring(0, index));
        } else {
            Test_Bindable = false;
            Test_Recusive = false;
        }
    }

    public static void TryAddQueueMemeber(LinkedList<Queue_member> queue,Queue_member now, Object obj, String name){
        BindingNode next;
        String path;
        int error_flag=0;
        if (now.path.isEmpty()){
            path=name;
        }
        else{
            path=now.path+"."+name;
        }
        String value=obj.toString();
        if (value.contains("E1rr0r_")){
            error_flag=1;
            value="1";
        }
        if (value.length()>300){
            value="1";
        }
        if (listGraph.isInGraph(obj)){
            next = listGraph.getNodeByObject(obj);
            test_chain(path,value);
            if (Test_Recusive){
                listGraph.addEdge(now.node, name, next);
                if (Test_Bindable){
                    if (!next.isBindable){
                        WritetoFile2(path+" "+ next.type+" "+ next.Mstring);
                    }
                    next.isBindable=true;
                }
            }

        }
        else {
            test_chain(path,value);
            if (error_flag==0 && Test_Recusive ) {
                next = listGraph.addNode(obj);
                listGraph.addEdge(now.node, name, next);
                if (Test_Bindable){
                    WritetoFile2(path+" "+ next.type+" "+ next.Mstring);
                    next.isBindable=true;
                }
                //add to queue
                Queue_member qm = new Queue_member();
                qm.node = next;
                qm.depth = now.depth - 1;
                qm.path = path;
                qm.obj = obj;
                queue.add(qm);
            }
            else if ( error_flag==1 && Test_Bindable){
                next = listGraph.addNode(obj);
                listGraph.addEdge(now.node, name, next);
                WritetoFile2(path+" "+ next.type+" "+ next.Mstring);
                next.isBindable=true;
            }
        }
    }

    public static void findandFillinGraph_BFS(Object start,String start_path,int depth) {

        int flag1=0;
        MetaProperty element;
        LinkedList<Queue_member> queue=new LinkedList<>();
        if (start==null)
        {
            println("First Object cannot be null!")
            return;
        }

        //创建队列的第一个节点
        Queue_member qm=new Queue_member();
        qm.node=listGraph.addNode(start);
        listGraph.firstNode=qm.node;
        qm.depth=depth;
        qm.path=start_path;
        qm.obj=start;
        queue.add(qm);
        //BFS
        while (!queue.isEmpty())
        {
            if (queue.size() %1000==0)
            {
                /*if (queue.size()<10000){
                    println("Graphsize:"+listGraph.getNodesize())
                }*/

                println(queue.size())
            }

            try{
                qm = queue.poll();
                if (qm.depth<=0) continue;
                if (listGraph.isBaseType(qm.obj))
                {
                    if (listGraph.BaseTypeVisited.contains(qm.obj.getClass()))
                        continue
                    else
                        listGraph.BaseTypeVisited.add(qm.obj.getClass())
                }
                SingleKeyHashMap propertyMap = getProperties(qm.obj)

                for (ComplexKeyHashMap.EntryIterator iter = propertyMap.getEntrySetIterator(); iter.hasNext(); ) {
                    try{
                        element = (MetaProperty) ((SingleKeyHashMap.Entry) iter.next()).value;

                        if(Modifier.isStatic(element.modifiers)){
                            continue
                        }
                        //it will crash in JDK11+ nestMembers
                        if (element.name[0].equals('_') || element.name.equals("nestHost0")|| element.name.equals("nestMembers")|| element.name.equals("nestMembers0") ||element.name.equals("permittedSubclasses0")||element.name.equals("recordComponents0")){
                            continue
                        }
                        if (qm.obj[element.name] != null) {
                            Class elementType=qm.obj[element.name].getClass();
                            if (elementType.isArray() || Collection.isAssignableFrom(elementType)) {
                                var elementArray = qm.obj[element.name]
                                int size = elementArray.size()
                                if (size > 2) {
                                    size = 2
                                }
                                for (i in 0..<size) {
                                    if (elementArray[i] != null) {
                                        TryAddQueueMemeber(queue,qm, elementArray[i], element.name + "[" + i + "]");
                                    }
                                }
                            }
                            else if (Map.isAssignableFrom(elementType)) {
                            }
                            else {
                                TryAddQueueMemeber(queue,qm, qm.obj[element.name], element.name);

                            }
                        }
                        else{
                            TryAddQueueMemeber(queue,qm,"E1rr0r_"+qm.path+element.name+"_M1typed_"+element.type.getName(),element.name);
                        }

                    }
                    catch(Exception ignored){
                        try {
                            TryAddQueueMemeber(queue,qm,"E1rr0r_"+qm.path+element.name+"_M1typed_"+element.type.getName(),element.name);
                        }
                        catch (Exception ignored2){

                        }
                    }
                }
            }
            catch (Exception e){
                e.printStackTrace()
                return
            }

        }



    }

    public static void find_allpath_inGraph(BindingNode now,int depth) {
        allpath_count++;
        BindingNode next;
        if (depth<=0)
            return;
        for (Map.Entry<String,BindingNode> entry: now.edgeList.entrySet()) {
            next=entry.getValue();
            if (!next.isVisited){
                next.isVisited=true;
                find_allpath_inGraph(next,depth-1);
                next.isVisited=false;
            }

        }
    }
    /*********************************
     ** depth no more than 10*********
     *********************************/
    public static String testGraph(Object obj,int depth) {

        listGraph.clear();

        Date start = new Date()
        Grails_Instrumentation.StartFlag=true;
        BNP_count=0;
        findandFillinGraph_BFS(obj,"title",depth);
        Grails_Instrumentation.StartFlag=false;
        Date stop = new Date()
        TimeDuration td = TimeCategory.minus( stop, start )
        def ss="ANP: "+listGraph.getNodesize()+" --- BNP: "+BNP_count+" --- Time: "+td;
        println(ss);
        WritetoFile(ss);
        return ss;

    }

    public static String testNP(Object obj,int depth) {

        listGraph.clear();
        Grails_Instrumentation.StartFlag=false;
        findandFillinGraph_BFS(obj,"title",depth);
        def ss="NP: "+listGraph.getNodesize();
        println(ss);
        WritetoFile(ss);
        return ss;

    }

    public static String testNP_and_AllPath(Object obj,int depth) {

        listGraph.clear();
        allpath_count=0;
        Grails_Instrumentation.StartFlag=false;
        findandFillinGraph_BFS(obj,"title",depth);
        listGraph.firstNode.isVisited=true;
        find_allpath_inGraph(listGraph.firstNode,depth);
        def ss="NP: "+listGraph.getNodesize()+" ----- allpathcount: "+allpath_count;
        println(ss);
        WritetoFile(ss);
        return ss;

    }

}