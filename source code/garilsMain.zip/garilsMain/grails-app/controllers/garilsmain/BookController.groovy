package garilsmain
import grails.databinding.Grails_Instrumentation

class BookController {

    def index() {
        def book = new Book();
        book.title="ssss";
        def TestChain = request.getParameterNames().iterator().next();
        Grails_Instrumentation ins=new Grails_Instrumentation(TestChain);
        bindData(book, params, [include: ['title']]);
        render ins.recursionflag.toString()+'_'+ins.bindingflag.toString()//+'   '+book.title
    }
}
