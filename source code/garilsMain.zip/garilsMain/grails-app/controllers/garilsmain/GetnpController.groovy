package garilsmain

class GetnpController {

    def index() {
        def book = new Book();
        NewGetPropertyChain n=new NewGetPropertyChain();
        String url=request.getRequestURL().toString();
        n.base_url=url.substring(0,url.toLowerCase().indexOf("/getnp"));
        book.title="sss";
        int depth=10;
        if (params.containsKey('depth')){
            depth=Integer.parseInt(params['depth'])
        }
        render n.testNP(book.title,depth);
    }
}
