package garilsmain

class GetThreadController {

    def index() {
        render Thread.activeCount();
    }
}
