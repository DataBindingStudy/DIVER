package garilsmain;

import java.util.HashMap;

public class BindingNode {
    public HashMap<String, BindingNode> edgeList;
    public String type;
    public String Mstring;
    public float weight;
    public boolean isBindable;
    public boolean isVisited;

    public BindingNode(){
        this.edgeList=new HashMap<>();
        this.weight=0;
        this.type="unKnown";
        this.Mstring="Mydefault";
        this.isBindable=false;
        this.isVisited=false;
    }

}