package garilsmain

class Book {
    String title
    static constraints = {
    }
}
