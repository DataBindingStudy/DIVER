package grails.databinding;

public class Grails_Instrumentation {
    public static boolean StartFlag=false;
    public static String request;
    public static String[] key;
    public static int now;
    public static boolean bindingflag=false;
    public static boolean recursionflag=false;

    private Grails_Instrumentation(){}
    /************************************
     * webRequestString can't be null
     * **********************************/
    public Grails_Instrumentation(String webRequestString){
       if (webRequestString==null || webRequestString.equals("")){
           throw new IllegalArgumentException("Parameters can't be null");
       }
       request=webRequestString;
       key=request.split("\\.");
       now=0;
       bindingflag=false;
       recursionflag=false;
    }

    public static void do_recursion()
    {
        if (!StartFlag) return;
        if (now < key.length){
            now++;
        }
        if (now==key.length){
            recursionflag=true;
        }
    }

    public static void do_binding()
    {
        if (!StartFlag) return;
        bindingflag=true;
    }

}

